/*
Add the 'skeleton' class to .coin
for x-ray vision, and to see how
the side of the coin is constructed.
*/